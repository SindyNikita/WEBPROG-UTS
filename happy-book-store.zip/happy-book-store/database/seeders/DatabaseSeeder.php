<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Category;
use App\Models\Book;
use App\Models\Detail;
class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //CATEGORY
        Category::create([
            'category' => 'Fiction'
        ]);
        Category::create([
            'category' => 'Science'
        ]);
        Category::create([
            'category' => 'Computer'
        ]);
        Category::create([
            'category' => 'Biography'
        ]);
        Category::create([
            'category' => 'Business/economics'
        ]);
        Category::create([
            'category' => 'Cookbook'
        ]);
        Category::create([
            'category' => 'Dictionary'
        ]);
        Category::create([
            'category' => 'Encyclopedia'
        ]);
        Category::create([
            'category' => 'History'
        ]);
        Category::create([
            'category' => 'Humor'
        ]);

        //BOOK
        Book::create([
            'category_id' => rand(1,10),
            'title' => "Lorem ipsum dolor"
        ]);
        Book::create([
            'category_id' => rand(1,10),
            'title' => "sit amet consectetur adipisicing elit."
        ]);
        Book::create([
            'category_id' => rand(1,10),
            'title' => "Sapiente perspiciatis quis, obcaecati"
        ]);
        Book::create([
            'category_id' => rand(1,10),
            'title' => "Laudantium, natus quo! Beatae excepturi"
        ]);
        Book::create([
            'category_id' => rand(1,10),
            'title' => "dolore aspernatur doloremque"
        ]);
        Book::create([
            'category_id' => rand(1,10),
            'title' => "iusto sed reprehenderit"
        ]);
        Book::create([
            'category_id' => rand(1,10),
            'title' => "quod maxime voluptatibus"
        ]);
        Book::create([
            'category_id' => rand(1,10),
            'title' => "doloribus excepturi cupiditate"
        ]);
        Book::create([
            'category_id' => rand(1,10),
            'title' => "voluptatem quasi dicta"
        ]);
        Book::create([
            'category_id' => rand(1,10),
            'title' => "explicabo nesciunt veniam"
        ]);
        Book::create([
            'category_id' => rand(1,10),
            'title' => "temporibus explicabo nesciunt"
        ]);
        Book::create([
            'category_id' => rand(1,10),
            'title' => "aspernatur quod maxime"
        ]);
        Book::create([
            'category_id' => rand(1,10),
            'title' => "aperiam inventore magnam"
        ]);
        //DETAIL
        Detail::create([
            'book_id' => 1,
            'author' => "Budi",
            'publisher' => "gramedia",
            'year' => 2015,
            'description' => "Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
            Deleniti minima facilis eum beatae? Incidunt facilis dolore aspernatur doloremque 
            voluptatem quasi dicta dolorum recusandae eos iste soluta porro praesentium ex 
            inventore odio, voluptates, iusto sed reprehenderit quos delectus culpa. Ratione 
            velit voluptate possimus, aliquam laboriosam veritatis veniam cum ea laborum sequi 
            qui dicta praesentium libero laudantium at enim, aspernatur esse quos vel. Eius 
            obcaecati nostrum corrupti, temporibus explicabo nesciunt veniam alias accusamus 
            impedit numquam dolore aspernatur quod maxime voluptatibus repellat placeat dolores 
            iste doloribus excepturi cupiditate? Autem, accusantium, rerum eligendi in officia, 
            sequi at id et aperiam inventore magnam quis perspiciatis."
        ]);
        Detail::create([
            'book_id' => 2,
            'author' => "Andi",
            'publisher' => "gramedia",
            'year' => 2016,
            'description' => "Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
            Deleniti minima facilis eum beatae? Incidunt facilis dolore aspernatur doloremque 
            voluptatem quasi dicta dolorum recusandae eos iste soluta porro praesentium ex 
            inventore odio, voluptates, iusto sed reprehenderit quos delectus culpa. Ratione 
            velit voluptate possimus, aliquam laboriosam veritatis veniam cum ea laborum sequi 
            qui dicta praesentium libero laudantium at enim, aspernatur esse quos vel. Eius 
            obcaecati nostrum corrupti, temporibus explicabo nesciunt veniam alias accusamus 
            impedit numquam dolore aspernatur quod maxime voluptatibus repellat placeat dolores 
            iste doloribus excepturi cupiditate? Autem, accusantium, rerum eligendi in officia, 
            sequi at id et aperiam inventore magnam quis perspiciatis."
        ]);
        Detail::create([
            'book_id' => 3,
            'author' => "Yanti",
            'publisher' => "gramedia",
            'year' => 2013,
            'description' => "Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
            Deleniti minima facilis eum beatae? Incidunt facilis dolore aspernatur doloremque 
            voluptatem quasi dicta dolorum recusandae eos iste soluta porro praesentium ex 
            inventore odio, voluptates, iusto sed reprehenderit quos delectus culpa. Ratione 
            velit voluptate possimus, aliquam laboriosam veritatis veniam cum ea laborum sequi 
            qui dicta praesentium libero laudantium at enim, aspernatur esse quos vel. Eius 
            obcaecati nostrum corrupti, temporibus explicabo nesciunt veniam alias accusamus 
            impedit numquam dolore aspernatur quod maxime voluptatibus repellat placeat dolores 
            iste doloribus excepturi cupiditate? Autem, accusantium, rerum eligendi in officia, 
            sequi at id et aperiam inventore magnam quis perspiciatis."
        ]);
        Detail::create([
            'book_id' => 4,
            'author' => "Ani",
            'publisher' => "gramedia",
            'year' => 2014,
            'description' => "Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
            Deleniti minima facilis eum beatae? Incidunt facilis dolore aspernatur doloremque 
            voluptatem quasi dicta dolorum recusandae eos iste soluta porro praesentium ex 
            inventore odio, voluptates, iusto sed reprehenderit quos delectus culpa. Ratione 
            velit voluptate possimus, aliquam laboriosam veritatis veniam cum ea laborum sequi 
            qui dicta praesentium libero laudantium at enim, aspernatur esse quos vel. Eius 
            obcaecati nostrum corrupti, temporibus explicabo nesciunt veniam alias accusamus 
            impedit numquam dolore aspernatur quod maxime voluptatibus repellat placeat dolores 
            iste doloribus excepturi cupiditate? Autem, accusantium, rerum eligendi in officia, 
            sequi at id et aperiam inventore magnam quis perspiciatis."
        ]);
        Detail::create([
            'book_id' => 5,
            'author' => "Yanto",
            'publisher' => "gramedia",
            'year' => 2020,
            'description' => "Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
            Deleniti minima facilis eum beatae? Incidunt facilis dolore aspernatur doloremque 
            voluptatem quasi dicta dolorum recusandae eos iste soluta porro praesentium ex 
            inventore odio, voluptates, iusto sed reprehenderit quos delectus culpa. Ratione 
            velit voluptate possimus, aliquam laboriosam veritatis veniam cum ea laborum sequi 
            qui dicta praesentium libero laudantium at enim, aspernatur esse quos vel. Eius 
            obcaecati nostrum corrupti, temporibus explicabo nesciunt veniam alias accusamus 
            impedit numquam dolore aspernatur quod maxime voluptatibus repellat placeat dolores 
            iste doloribus excepturi cupiditate? Autem, accusantium, rerum eligendi in officia, 
            sequi at id et aperiam inventore magnam quis perspiciatis."
        ]);
        Detail::create([
            'book_id' => 6,
            'author' => "Agus",
            'publisher' => "gramedia",
            'year' => 2007,
            'description' => "Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
            Deleniti minima facilis eum beatae? Incidunt facilis dolore aspernatur doloremque 
            voluptatem quasi dicta dolorum recusandae eos iste soluta porro praesentium ex 
            inventore odio, voluptates, iusto sed reprehenderit quos delectus culpa. Ratione 
            velit voluptate possimus, aliquam laboriosam veritatis veniam cum ea laborum sequi 
            qui dicta praesentium libero laudantium at enim, aspernatur esse quos vel. Eius 
            obcaecati nostrum corrupti, temporibus explicabo nesciunt veniam alias accusamus 
            impedit numquam dolore aspernatur quod maxime voluptatibus repellat placeat dolores 
            iste doloribus excepturi cupiditate? Autem, accusantium, rerum eligendi in officia, 
            sequi at id et aperiam inventore magnam quis perspiciatis."
        ]);
        Detail::create([
            'book_id' => 7,
            'author' => "Joko",
            'publisher' => "gramedia",
            'year' => 2005,
            'description' => "Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
            Deleniti minima facilis eum beatae? Incidunt facilis dolore aspernatur doloremque 
            voluptatem quasi dicta dolorum recusandae eos iste soluta porro praesentium ex 
            inventore odio, voluptates, iusto sed reprehenderit quos delectus culpa. Ratione 
            velit voluptate possimus, aliquam laboriosam veritatis veniam cum ea laborum sequi 
            qui dicta praesentium libero laudantium at enim, aspernatur esse quos vel. Eius 
            obcaecati nostrum corrupti, temporibus explicabo nesciunt veniam alias accusamus 
            impedit numquam dolore aspernatur quod maxime voluptatibus repellat placeat dolores 
            iste doloribus excepturi cupiditate? Autem, accusantium, rerum eligendi in officia, 
            sequi at id et aperiam inventore magnam quis perspiciatis."
        ]);
        Detail::create([
            'book_id' => 8,
            'author' => "Wahyu",
            'publisher' => "gramedia",
            'year' => 2010,
            'description' => "Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
            Deleniti minima facilis eum beatae? Incidunt facilis dolore aspernatur doloremque 
            voluptatem quasi dicta dolorum recusandae eos iste soluta porro praesentium ex 
            inventore odio, voluptates, iusto sed reprehenderit quos delectus culpa. Ratione 
            velit voluptate possimus, aliquam laboriosam veritatis veniam cum ea laborum sequi 
            qui dicta praesentium libero laudantium at enim, aspernatur esse quos vel. Eius 
            obcaecati nostrum corrupti, temporibus explicabo nesciunt veniam alias accusamus 
            impedit numquam dolore aspernatur quod maxime voluptatibus repellat placeat dolores 
            iste doloribus excepturi cupiditate? Autem, accusantium, rerum eligendi in officia, 
            sequi at id et aperiam inventore magnam quis perspiciatis."
        ]);
        Detail::create([
            'book_id' => 9,
            'author' => "Rudi",
            'publisher' => "gramedia",
            'year' => 2016,
            'description' => "Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
            Deleniti minima facilis eum beatae? Incidunt facilis dolore aspernatur doloremque 
            voluptatem quasi dicta dolorum recusandae eos iste soluta porro praesentium ex 
            inventore odio, voluptates, iusto sed reprehenderit quos delectus culpa. Ratione 
            velit voluptate possimus, aliquam laboriosam veritatis veniam cum ea laborum sequi 
            qui dicta praesentium libero laudantium at enim, aspernatur esse quos vel. Eius 
            obcaecati nostrum corrupti, temporibus explicabo nesciunt veniam alias accusamus 
            impedit numquam dolore aspernatur quod maxime voluptatibus repellat placeat dolores 
            iste doloribus excepturi cupiditate? Autem, accusantium, rerum eligendi in officia, 
            sequi at id et aperiam inventore magnam quis perspiciatis."
        ]);
        Detail::create([
            'book_id' => 10,
            'author' => "Bambang",
            'publisher' => "gramedia",
            'year' => 2012,
            'description' => "Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
            Deleniti minima facilis eum beatae? Incidunt facilis dolore aspernatur doloremque 
            voluptatem quasi dicta dolorum recusandae eos iste soluta porro praesentium ex 
            inventore odio, voluptates, iusto sed reprehenderit quos delectus culpa. Ratione 
            velit voluptate possimus, aliquam laboriosam veritatis veniam cum ea laborum sequi 
            qui dicta praesentium libero laudantium at enim, aspernatur esse quos vel. Eius 
            obcaecati nostrum corrupti, temporibus explicabo nesciunt veniam alias accusamus 
            impedit numquam dolore aspernatur quod maxime voluptatibus repellat placeat dolores 
            iste doloribus excepturi cupiditate? Autem, accusantium, rerum eligendi in officia, 
            sequi at id et aperiam inventore magnam quis perspiciatis."
        ]);
        Detail::create([
            'book_id' => 11,
            'author' => "Gusti",
            'publisher' => "gramedia",
            'year' => 2019,
            'description' => "Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
            Deleniti minima facilis eum beatae? Incidunt facilis dolore aspernatur doloremque 
            voluptatem quasi dicta dolorum recusandae eos iste soluta porro praesentium ex 
            inventore odio, voluptates, iusto sed reprehenderit quos delectus culpa. Ratione 
            velit voluptate possimus, aliquam laboriosam veritatis veniam cum ea laborum sequi 
            qui dicta praesentium libero laudantium at enim, aspernatur esse quos vel. Eius 
            obcaecati nostrum corrupti, temporibus explicabo nesciunt veniam alias accusamus 
            impedit numquam dolore aspernatur quod maxime voluptatibus repellat placeat dolores 
            iste doloribus excepturi cupiditate? Autem, accusantium, rerum eligendi in officia, 
            sequi at id et aperiam inventore magnam quis perspiciatis."
        ]);
        Detail::create([
            'book_id' => 12,
            'author' => "Sidik",
            'publisher' => "gramedia",
            'year' => 2017,
            'description' => "Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
            Deleniti minima facilis eum beatae? Incidunt facilis dolore aspernatur doloremque 
            voluptatem quasi dicta dolorum recusandae eos iste soluta porro praesentium ex 
            inventore odio, voluptates, iusto sed reprehenderit quos delectus culpa. Ratione 
            velit voluptate possimus, aliquam laboriosam veritatis veniam cum ea laborum sequi 
            qui dicta praesentium libero laudantium at enim, aspernatur esse quos vel. Eius 
            obcaecati nostrum corrupti, temporibus explicabo nesciunt veniam alias accusamus 
            impedit numquam dolore aspernatur quod maxime voluptatibus repellat placeat dolores 
            iste doloribus excepturi cupiditate? Autem, accusantium, rerum eligendi in officia, 
            sequi at id et aperiam inventore magnam quis perspiciatis."
        ]);
        Detail::create([
            'book_id' => 13,
            'author' => "Kevin",
            'publisher' => "gramedia",
            'year' => 2016,
            'description' => "Lorem, ipsum dolor sit amet consectetur adipisicing elit. 
            Deleniti minima facilis eum beatae? Incidunt facilis dolore aspernatur doloremque 
            voluptatem quasi dicta dolorum recusandae eos iste soluta porro praesentium ex 
            inventore odio, voluptates, iusto sed reprehenderit quos delectus culpa. Ratione 
            velit voluptate possimus, aliquam laboriosam veritatis veniam cum ea laborum sequi 
            qui dicta praesentium libero laudantium at enim, aspernatur esse quos vel. Eius 
            obcaecati nostrum corrupti, temporibus explicabo nesciunt veniam alias accusamus 
            impedit numquam dolore aspernatur quod maxime voluptatibus repellat placeat dolores 
            iste doloribus excepturi cupiditate? Autem, accusantium, rerum eligendi in officia, 
            sequi at id et aperiam inventore magnam quis perspiciatis."
        ]);
    }
}