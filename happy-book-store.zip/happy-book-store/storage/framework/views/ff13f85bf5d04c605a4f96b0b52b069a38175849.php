<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://cdn.datatables.net/1.11.2/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/1.11.2/js/dataTables.bootstrap4.min.js"></script>
        <title>Home</title>
        <style>
            .pagination{
                justify-content: right!important;
            }
            .dataTables_empty{
                background: rgb(255, 208, 0); 
            }
        </style>
    </head>
    <body>
        <div class="container-fluid">
            <div class="row" style="padding: 30px;background:rgb(0, 89, 255);color:white">
                <div class="col">
                    <h1 style="text-align: center">HAPPY BOOK STORE</h1>
                </div>
            </div>
            <div class="row">
                <div class="col">
                    <nav class="navbar navbar-expand-lg navbar-light bg-light">
                        <div class="collapse navbar-collapse" id="navbarNav"  style="justify-content: center">
                            <ul class="navbar-nav">
                                <li class="nav-item active">
                                    <a class="nav-link" href="/">Home</a>
                                </li>
                                <li class="nav-item dropdown">
                                    <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        Category
                                    </a>
                                    <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a class="dropdown-item" href="<?php echo e(url('category/'.$category->id)); ?>"><?php echo e($category->category); ?></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(url('contact')); ?>">Contact</a>
                                </li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
            <div class="row" style="margin-top: 25px">
                <div class="col">
                </div>
                <div class="col-7">
                    <h5 style="background: rgb(255, 208, 0);padding:5px">Book Detail</h5>
                    <h3>
                        Store Address :
                    </h3>
                    <p>Jalan Pembangunan Raya</p>
                    <p>Kompleks Pertokoan Emerald Blok III/12</p>
                    <p>Bintaro, Tangerang Selatan</p>
                    <p>Indonesia</p>
                    <h3>
                        Open Daily :
                    </h3>
                    <p>08.00 - 20.00</p>
                    <h3>
                        Contact :
                    </h3>
                    <p>Phone : 021-08899776655</p>
                    <p>Email : happybookstore@happy.com</p>
                </div>
                <div class="col">
                    <h5 style="background: rgb(255, 208, 0);padding:5px">Category</h5>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('category/'.$category->id)); ?>"><p><?php echo e($category->category); ?></p></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\2725\happy-book-store\resources\views/contact.blade.php ENDPATH**/ ?>