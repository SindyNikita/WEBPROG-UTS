<?php

namespace App\Http\Controllers;
use App\Models\Book;
use App\Models\Category;
use Illuminate\Http\Request;

class Detail extends Controller
{
    public function __construct(){
        $this->book = new Book();
    }
    public function index($id)
    {
        $list_category = Category::All();
        $book = $this->book->getSelectedBook($id);
        return view('detail')->with('book', $book)->with('categories',$list_category);
    }
}
