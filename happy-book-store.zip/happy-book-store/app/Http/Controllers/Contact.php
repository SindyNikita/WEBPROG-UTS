<?php

namespace App\Http\Controllers;
use App\Models\Book;
use App\Models\Category;
use Illuminate\Http\Request;

class Contact extends Controller
{
    public function __construct(){
        $this->book = new Book();
    }
    public function index()
    {
        $list_category = Category::All();
        return view('contact')->with('categories',$list_category);
    }
}
