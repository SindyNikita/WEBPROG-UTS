<?php

namespace App\Http\Controllers;
use App\Models\Book;
use App\Models\Category;
class Home extends Controller
{
    protected $books;
    public function __construct(){
        $this->books = new Book();
        $this->category = new Category();
    }
    public function index()
    {
        $list_category = Category::All();
        $list_books = $this->books->getAllData();
        $title = "Book list";
        return view('home')->with('books', $list_books)->with('categories',$list_category)->with('title',$title);
    }
    public function selected_category($category){
        $list_category = Category::All();
        $list_books = $this->books->getSelectedData($category);
        $title = $this->category->getSelectedCategory($category)->category;
        return view('home')->with('books', $list_books)->with('categories',$list_category)->with('title',$title);
    }
}
