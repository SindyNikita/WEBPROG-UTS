<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    public $timestamps = false;
    use HasFactory;
    public function getAllData()
    {
        return $this
            ->leftJoin('details', 'books.id', '=', 'details.book_id')
            ->select('*')
            ->get();
    }
    public function getSelectedData($category)
    {
        return $this
            ->leftJoin('details', 'books.id', '=', 'details.book_id')
            ->select('*')
            ->where('books.category_id','=',$category)
            ->get();
    }
    public function getSelectedBook($id)
    {
        return $this
            ->leftJoin('details', 'books.id', '=', 'details.book_id')
            ->select('*')
            ->where('books.id','=',$id)
            ->get()->first();
    }
}
